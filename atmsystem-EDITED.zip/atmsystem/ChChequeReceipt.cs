﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class ChChequeReceipt : Form
    {
        private double amount;
        private string accountNumber;
        public ChChequeReceipt(double amount, string accountNumber)
        {
            InitializeComponent();
            this.amount = amount;
            this.accountNumber = accountNumber;
            this.Load += ChChequeReceipt_Load;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ChChequeReceipt_Load(object sender, EventArgs e)
        {
            CurentBalCheque.Text = amount.ToString();
            lblAccNum.Text = accountNumber;
        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void lblAccNum_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace atmsystem
{
    partial class ChSavingsReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChSavingsReceipt));
            lblAccNum = new Label();
            CurrentBalSavings = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(504, 131);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(39, 26);
            lblAccNum.TabIndex = 10;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // CurrentBalSavings
            // 
            CurrentBalSavings.AutoSize = true;
            CurrentBalSavings.BackColor = Color.Transparent;
            CurrentBalSavings.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            CurrentBalSavings.ForeColor = Color.DarkSlateGray;
            CurrentBalSavings.Location = new Point(504, 198);
            CurrentBalSavings.Name = "CurrentBalSavings";
            CurrentBalSavings.Size = new Size(39, 26);
            CurrentBalSavings.TabIndex = 11;
            CurrentBalSavings.Text = "---";
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(327, 244);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(163, 43);
            proceedBtn.TabIndex = 12;
            proceedBtn.Text = "Proceed";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // ChSavingsReceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(800, 329);
            Controls.Add(proceedBtn);
            Controls.Add(CurrentBalSavings);
            Controls.Add(lblAccNum);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "ChSavingsReceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChSavingsReceipt";
            Load += ChSavingsReceipt_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblAccNum;
        private Label CurrentBalSavings;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
    }
}
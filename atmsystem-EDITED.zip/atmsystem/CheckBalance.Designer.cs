﻿namespace atmsystem
{
    partial class CheckBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckBalance));
            SavingsBtn = new Guna.UI2.WinForms.Guna2Button();
            ChequeBtn = new Guna.UI2.WinForms.Guna2Button();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // SavingsBtn
            // 
            SavingsBtn.BackColor = Color.Transparent;
            SavingsBtn.BorderColor = Color.DarkSlateGray;
            SavingsBtn.BorderRadius = 15;
            SavingsBtn.BorderThickness = 2;
            SavingsBtn.CustomizableEdges = customizableEdges1;
            SavingsBtn.DisabledState.BorderColor = Color.DarkGray;
            SavingsBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            SavingsBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            SavingsBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            SavingsBtn.FillColor = Color.Teal;
            SavingsBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SavingsBtn.ForeColor = Color.White;
            SavingsBtn.Location = new Point(111, 438);
            SavingsBtn.Name = "SavingsBtn";
            SavingsBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            SavingsBtn.Size = new Size(235, 48);
            SavingsBtn.TabIndex = 6;
            SavingsBtn.Text = "Savings";
            SavingsBtn.Click += SavingsBtn_Click;
            // 
            // ChequeBtn
            // 
            ChequeBtn.BackColor = Color.Transparent;
            ChequeBtn.BorderColor = Color.DarkSlateGray;
            ChequeBtn.BorderRadius = 15;
            ChequeBtn.BorderThickness = 2;
            ChequeBtn.CustomizableEdges = customizableEdges3;
            ChequeBtn.DisabledState.BorderColor = Color.DarkGray;
            ChequeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ChequeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ChequeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ChequeBtn.FillColor = Color.Teal;
            ChequeBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ChequeBtn.ForeColor = Color.White;
            ChequeBtn.Location = new Point(111, 502);
            ChequeBtn.Name = "ChequeBtn";
            ChequeBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            ChequeBtn.Size = new Size(235, 48);
            ChequeBtn.TabIndex = 7;
            ChequeBtn.Text = "Cheque";
            ChequeBtn.Click += ChequeBtn_Click;
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges5;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(111, 568);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 9;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // CheckBalance
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(452, 718);
            Controls.Add(cancelBtn);
            Controls.Add(ChequeBtn);
            Controls.Add(SavingsBtn);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "CheckBalance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CheckBalance";
            Load += CheckBalance_Load;
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button SavingsBtn;
        private Guna.UI2.WinForms.Guna2Button ChequeBtn;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}
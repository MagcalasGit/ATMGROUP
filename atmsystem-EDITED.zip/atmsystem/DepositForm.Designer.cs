﻿namespace atmsystem
{
    partial class DepositForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepositForm));
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            DepositChequeBtn = new Guna.UI2.WinForms.Guna2Button();
            DepositSavingsBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges1;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(111, 590);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 15;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // DepositChequeBtn
            // 
            DepositChequeBtn.BackColor = Color.Transparent;
            DepositChequeBtn.BorderColor = Color.DarkSlateGray;
            DepositChequeBtn.BorderRadius = 15;
            DepositChequeBtn.BorderThickness = 2;
            DepositChequeBtn.CustomizableEdges = customizableEdges3;
            DepositChequeBtn.DisabledState.BorderColor = Color.DarkGray;
            DepositChequeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            DepositChequeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            DepositChequeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            DepositChequeBtn.FillColor = Color.Teal;
            DepositChequeBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositChequeBtn.ForeColor = Color.White;
            DepositChequeBtn.Location = new Point(111, 527);
            DepositChequeBtn.Name = "DepositChequeBtn";
            DepositChequeBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            DepositChequeBtn.Size = new Size(235, 48);
            DepositChequeBtn.TabIndex = 14;
            DepositChequeBtn.Text = "Cheque";
            DepositChequeBtn.Click += DepositChequeBtn_Click;
            // 
            // DepositSavingsBtn
            // 
            DepositSavingsBtn.BackColor = Color.Transparent;
            DepositSavingsBtn.BorderColor = Color.DarkSlateGray;
            DepositSavingsBtn.BorderRadius = 15;
            DepositSavingsBtn.BorderThickness = 2;
            DepositSavingsBtn.CustomizableEdges = customizableEdges5;
            DepositSavingsBtn.DisabledState.BorderColor = Color.DarkGray;
            DepositSavingsBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            DepositSavingsBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            DepositSavingsBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            DepositSavingsBtn.FillColor = Color.Teal;
            DepositSavingsBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositSavingsBtn.ForeColor = Color.White;
            DepositSavingsBtn.Location = new Point(111, 461);
            DepositSavingsBtn.Name = "DepositSavingsBtn";
            DepositSavingsBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            DepositSavingsBtn.Size = new Size(235, 48);
            DepositSavingsBtn.TabIndex = 13;
            DepositSavingsBtn.Text = "Savings";
            DepositSavingsBtn.Click += DepositSavingsBtn_Click;
            // 
            // DepositForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(452, 747);
            Controls.Add(cancelBtn);
            Controls.Add(DepositChequeBtn);
            Controls.Add(DepositSavingsBtn);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DepositForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DepositForm";
            Load += DepositForm_Load;
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
        private Guna.UI2.WinForms.Guna2Button DepositChequeBtn;
        private Guna.UI2.WinForms.Guna2Button DepositSavingsBtn;
    }
}
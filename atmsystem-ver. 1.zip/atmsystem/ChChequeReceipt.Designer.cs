﻿namespace atmsystem
{
    partial class ChChequeReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChChequeReceipt));
            lblAccNum = new Label();
            CurentBalCheque = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            SuspendLayout();
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(661, 181);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(47, 32);
            lblAccNum.TabIndex = 12;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // CurentBalCheque
            // 
            CurentBalCheque.AutoSize = true;
            CurentBalCheque.BackColor = Color.Transparent;
            CurentBalCheque.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            CurentBalCheque.ForeColor = Color.DarkSlateGray;
            CurentBalCheque.Location = new Point(661, 268);
            CurentBalCheque.Name = "CurentBalCheque";
            CurentBalCheque.Size = new Size(47, 32);
            CurentBalCheque.TabIndex = 13;
            CurentBalCheque.Text = "---";
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(453, 331);
            proceedBtn.Margin = new Padding(3, 4, 3, 4);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(190, 56);
            proceedBtn.TabIndex = 14;
            proceedBtn.Text = "Proceed";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.LightCyan;
            guna2HtmlLabel2.Location = new Point(644, 257);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(11, 43);
            guna2HtmlLabel2.TabIndex = 16;
            guna2HtmlLabel2.Text = ":";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.LightCyan;
            guna2HtmlLabel1.Location = new Point(644, 168);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(11, 43);
            guna2HtmlLabel1.TabIndex = 15;
            guna2HtmlLabel1.Text = ":";
            // 
            // ChChequeReceipt
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1068, 439);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(proceedBtn);
            Controls.Add(CurentBalCheque);
            Controls.Add(lblAccNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "ChChequeReceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChChequeReceipt";
            Load += ChChequeReceipt_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblAccNum;
        private Label CurentBalCheque;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}
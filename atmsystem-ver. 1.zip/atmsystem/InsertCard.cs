﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class InsertCard : Form
    {
        public InsertCard()
        {
            InitializeComponent();
        }

        private void txtCardNum_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCardNum.Text, out int cardNum))
            {
                MessageBox.Show("Please enter a valid number.");
                txtCardNum.Text = string.Empty;
                enterBtn.Enabled = false;
            }
            else
            {
                enterBtn.Enabled = true;
            }
        }

        private void enterBtn_Click(object sender, EventArgs e)
        {
            if (txtCardNum.Text == "0000")
            {
                Form1 insertCard = new Form1();
                this.Hide();
                insertCard.Show();
            }
            else
            {
                MessageBox.Show("Please enter '0000'.");
            }
        }

        private void InsertCard_Load(object sender, EventArgs e)
        {
            enterBtn.Enabled = false;
        }
    }
}

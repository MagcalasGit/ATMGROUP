﻿namespace atmsystem
{
    partial class WithdrawSavings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WithdrawSavings));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            savingsAmount = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            confirmBtn = new Guna.UI2.WinForms.Guna2Button();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(450, 425);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(529, 25);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(248, 34);
            guna2HtmlLabel1.TabIndex = 11;
            guna2HtmlLabel1.Text = "WITHDRAW SAVINGS";
            // 
            // savingsAmount
            // 
            savingsAmount.BorderColor = Color.DarkSlateGray;
            savingsAmount.BorderRadius = 15;
            savingsAmount.BorderThickness = 2;
            savingsAmount.CustomizableEdges = customizableEdges1;
            savingsAmount.DefaultText = "";
            savingsAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            savingsAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            savingsAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            savingsAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            savingsAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            savingsAmount.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            savingsAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            savingsAmount.Location = new Point(471, 157);
            savingsAmount.Margin = new Padding(4, 3, 4, 3);
            savingsAmount.Name = "savingsAmount";
            savingsAmount.PasswordChar = '\0';
            savingsAmount.PlaceholderText = "Enter Amount";
            savingsAmount.SelectedText = "";
            savingsAmount.ShadowDecoration.CustomizableEdges = customizableEdges2;
            savingsAmount.Size = new Size(344, 55);
            savingsAmount.TabIndex = 12;
            savingsAmount.TextChanged += savingsAmount_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(486, 133);
            label1.Name = "label1";
            label1.Size = new Size(162, 21);
            label1.TabIndex = 13;
            label1.Text = "Enter Amount here:";
            // 
            // confirmBtn
            // 
            confirmBtn.BackColor = Color.LightCyan;
            confirmBtn.BorderColor = Color.DarkCyan;
            confirmBtn.BorderRadius = 15;
            confirmBtn.BorderThickness = 2;
            confirmBtn.CustomizableEdges = customizableEdges3;
            confirmBtn.DisabledState.BorderColor = Color.DarkGray;
            confirmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            confirmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            confirmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            confirmBtn.FillColor = Color.DarkSlateGray;
            confirmBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            confirmBtn.ForeColor = Color.White;
            confirmBtn.Location = new Point(486, 333);
            confirmBtn.Name = "confirmBtn";
            confirmBtn.PressedColor = Color.DarkSlateGray;
            confirmBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            confirmBtn.Size = new Size(141, 45);
            confirmBtn.TabIndex = 14;
            confirmBtn.Text = "Confirm";
            confirmBtn.Click += confirmBtn_Click;
            // 
            // cancelBtn
            // 
            cancelBtn.BorderColor = Color.DarkCyan;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges5;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.DarkSlateGray;
            cancelBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(662, 333);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            cancelBtn.Size = new Size(141, 45);
            cancelBtn.TabIndex = 16;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // WithdrawSavings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(845, 425);
            Controls.Add(cancelBtn);
            Controls.Add(confirmBtn);
            Controls.Add(label1);
            Controls.Add(savingsAmount);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "WithdrawSavings";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "WithdrawSavings";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox savingsAmount;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button confirmBtn;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}
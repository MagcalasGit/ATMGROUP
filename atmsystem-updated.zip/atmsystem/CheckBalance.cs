﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class CheckBalance : Form
    {
        public CheckBalance()
        {
            InitializeComponent();
        }

        private void SavingsBtn_Click(object sender, EventArgs e)
        {
            ChSavingsReceipt savingsReceipt = new ChSavingsReceipt(AccountInfo.savingsAmount, AccountInfo.accountNumber);
            this.Hide();
            savingsReceipt.Show();
        }

        private void ChequeBtn_Click(object sender, EventArgs e)
        {
            ChSavingsReceipt savingsReceipt = new ChSavingsReceipt(AccountInfo.chequeAmount, AccountInfo.accountNumber);
            this.Hide();
            savingsReceipt.Show();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void CheckBalance_Load(object sender, EventArgs e)
        {

        }
    }
}

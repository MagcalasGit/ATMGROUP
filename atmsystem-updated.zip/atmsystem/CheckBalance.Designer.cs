﻿namespace atmsystem
{
    partial class CheckBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckBalance));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            SavingsBtn = new Guna.UI2.WinForms.Guna2Button();
            ChequeBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(450, 425);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // SavingsBtn
            // 
            SavingsBtn.BorderColor = Color.DarkCyan;
            SavingsBtn.BorderRadius = 15;
            SavingsBtn.BorderThickness = 2;
            SavingsBtn.CustomizableEdges = customizableEdges1;
            SavingsBtn.DisabledState.BorderColor = Color.DarkGray;
            SavingsBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            SavingsBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            SavingsBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            SavingsBtn.FillColor = Color.DarkSlateGray;
            SavingsBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SavingsBtn.ForeColor = Color.White;
            SavingsBtn.Location = new Point(106, 507);
            SavingsBtn.Name = "SavingsBtn";
            SavingsBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            SavingsBtn.Size = new Size(235, 48);
            SavingsBtn.TabIndex = 6;
            SavingsBtn.Text = "Savings";
            SavingsBtn.Click += SavingsBtn_Click;
            // 
            // ChequeBtn
            // 
            ChequeBtn.BorderColor = Color.DarkCyan;
            ChequeBtn.BorderRadius = 15;
            ChequeBtn.BorderThickness = 2;
            ChequeBtn.CustomizableEdges = customizableEdges3;
            ChequeBtn.DisabledState.BorderColor = Color.DarkGray;
            ChequeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ChequeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ChequeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ChequeBtn.FillColor = Color.DarkSlateGray;
            ChequeBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ChequeBtn.ForeColor = Color.White;
            ChequeBtn.Location = new Point(106, 571);
            ChequeBtn.Name = "ChequeBtn";
            ChequeBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            ChequeBtn.Size = new Size(235, 48);
            ChequeBtn.TabIndex = 7;
            ChequeBtn.Text = "Cheque";
            ChequeBtn.Click += ChequeBtn_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(126, 439);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(196, 34);
            guna2HtmlLabel1.TabIndex = 8;
            guna2HtmlLabel1.Text = "CHECK BALANCE";
            // 
            // cancelBtn
            // 
            cancelBtn.BorderColor = Color.DarkCyan;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges5;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.DarkSlateGray;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(106, 634);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 9;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // CheckBalance
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(452, 694);
            Controls.Add(cancelBtn);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(ChequeBtn);
            Controls.Add(SavingsBtn);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "CheckBalance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CheckBalance";
            Load += CheckBalance_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button SavingsBtn;
        private Guna.UI2.WinForms.Guna2Button ChequeBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}
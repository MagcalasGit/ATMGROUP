﻿namespace atmsystem
{
    partial class depositSavingsrecepit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(depositSavingsrecepit));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBalAdd = new Label();
            lblAmountAdded = new Label();
            lblAccNum = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(356, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // proceedBtn
            // 
            proceedBtn.BorderColor = Color.DarkCyan;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges11;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.DarkSlateGray;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(382, 273);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges12;
            proceedBtn.Size = new Size(282, 45);
            proceedBtn.TabIndex = 25;
            proceedBtn.Text = "Proceed to Merchant";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // lblCurrentBalAdd
            // 
            lblCurrentBalAdd.AutoSize = true;
            lblCurrentBalAdd.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBalAdd.ForeColor = Color.DarkSlateGray;
            lblCurrentBalAdd.Location = new Point(579, 204);
            lblCurrentBalAdd.Name = "lblCurrentBalAdd";
            lblCurrentBalAdd.Size = new Size(39, 28);
            lblCurrentBalAdd.TabIndex = 24;
            lblCurrentBalAdd.Text = "---";
            lblCurrentBalAdd.Click += lblCurrentBalAdd_Click;
            // 
            // lblAmountAdded
            // 
            lblAmountAdded.AutoSize = true;
            lblAmountAdded.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountAdded.ForeColor = Color.DarkSlateGray;
            lblAmountAdded.Location = new Point(579, 140);
            lblAmountAdded.Name = "lblAmountAdded";
            lblAmountAdded.Size = new Size(39, 28);
            lblAmountAdded.TabIndex = 23;
            lblAmountAdded.Text = "---";
            lblAmountAdded.Click += lblAmountAdded_Click;
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(579, 76);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(39, 28);
            lblAccNum.TabIndex = 22;
            lblAccNum.Text = "---";

            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(401, 140);
            label3.Name = "label3";
            label3.Size = new Size(172, 28);
            label3.TabIndex = 21;
            label3.Text = "Amount Added:";

            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(393, 204);
            label1.Name = "label1";
            label1.Size = new Size(180, 28);
            label1.TabIndex = 20;
            label1.Text = "Current Balance:";

            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(382, 76);
            label2.Name = "label2";
            label2.Size = new Size(191, 28);
            label2.TabIndex = 19;
            label2.Text = "Account Number:";

            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(470, 13);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(230, 34);
            guna2HtmlLabel1.TabIndex = 18;
            guna2HtmlLabel1.Text = "Transaction Receipt";

            // 
            // depositSavingsrecepit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(800, 329);
            Controls.Add(proceedBtn);
            Controls.Add(lblCurrentBalAdd);
            Controls.Add(lblAmountAdded);
            Controls.Add(lblAccNum);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "depositSavingsrecepit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "depositSavingsrecepit";
            Load += depositSavingsrecepit_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
        private Label lblCurrentBalAdd;
        private Label lblAmountAdded;
        private Label lblAccNum;
        private Label label3;
        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}
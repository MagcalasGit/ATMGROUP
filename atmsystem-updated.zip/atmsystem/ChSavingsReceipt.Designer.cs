﻿namespace atmsystem
{
    partial class ChSavingsReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChSavingsReceipt));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            label1 = new Label();
            label2 = new Label();
            lblAccNum = new Label();
            CurrentBalSavings = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(356, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(485, 12);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(188, 34);
            guna2HtmlLabel1.TabIndex = 7;
            guna2HtmlLabel1.Text = "Savings Balance";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(385, 191);
            label1.Name = "label1";
            label1.Size = new Size(180, 28);
            label1.TabIndex = 8;
            label1.Text = "Current Balance:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(385, 79);
            label2.Name = "label2";
            label2.Size = new Size(191, 28);
            label2.TabIndex = 9;
            label2.Text = "Account Number:";
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(573, 79);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(39, 28);
            lblAccNum.TabIndex = 10;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // CurrentBalSavings
            // 
            CurrentBalSavings.AutoSize = true;
            CurrentBalSavings.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CurrentBalSavings.ForeColor = Color.DarkSlateGray;
            CurrentBalSavings.Location = new Point(561, 191);
            CurrentBalSavings.Name = "CurrentBalSavings";
            CurrentBalSavings.Size = new Size(39, 28);
            CurrentBalSavings.TabIndex = 11;
            CurrentBalSavings.Text = "---";
            // 
            // proceedBtn
            // 
            proceedBtn.BorderColor = Color.DarkCyan;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.DarkSlateGray;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(385, 261);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(180, 45);
            proceedBtn.TabIndex = 12;
            proceedBtn.Text = "Proceed";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // ChSavingsReceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(800, 329);
            Controls.Add(proceedBtn);
            Controls.Add(CurrentBalSavings);
            Controls.Add(lblAccNum);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "ChSavingsReceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChSavingsReceipt";
            Load += ChSavingsReceipt_Load_1;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Label label1;
        private Label label2;
        private Label lblAccNum;
        private Label CurrentBalSavings;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
    }
}
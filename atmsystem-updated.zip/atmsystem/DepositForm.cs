﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class DepositForm : Form
    {
        public DepositForm()
        {
            InitializeComponent();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void DepositSavingsBtn_Click(object sender, EventArgs e)
        {
            DepositSavings goDeposit = new DepositSavings();
            this.Hide();
            goDeposit.Show();
        }

        private void DepositChequeBtn_Click(object sender, EventArgs e)
        {
            DepositCheque goDepCheque = new DepositCheque();
            this.Hide();
            goDepCheque.Show();
        }

        private void DepositForm_Load(object sender, EventArgs e)
        {

        }
    }
}

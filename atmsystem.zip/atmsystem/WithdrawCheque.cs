﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class WithdrawCheque : Form
    {
        public WithdrawCheque()
        {
            InitializeComponent();
        }

        private void chequeAmount_TextChanged(object sender, EventArgs e)
        {
            double amount;
            if (!double.TryParse(chequeAmount.Text, out amount))
            {
                chequeAmount.Text = "";
                confirmBtn.Enabled = false;
            }
            else
            {
                if (amount > AccountInfo.chequeAmount)
                {
                    confirmBtn.Enabled = false;
                }
                else
                {
                    confirmBtn.Enabled = true;
                }
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double withdrawalAmount;
            if (double.TryParse(chequeAmount.Text, out withdrawalAmount))
            {
                if (withdrawalAmount <= AccountInfo.chequeAmount)
                {
                    AccountInfo.chequeAmount -= withdrawalAmount;
                    withdrawChequereceipt receipt = new withdrawChequereceipt(withdrawalAmount);
                    this.Hide();
                    receipt.Show();
                }
                else
                {
                    MessageBox.Show("Insufficient balance");
                }
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private void WithdrawCheque_Load(object sender, EventArgs e)
        {

        }
    }
}

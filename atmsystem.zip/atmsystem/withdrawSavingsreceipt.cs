﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class withdrawSavingsreceipt : Form
    {
        private double withdrawalamount;
        public withdrawSavingsreceipt(double withdrawalamount)
        {
            InitializeComponent();
            this.withdrawalamount = withdrawalamount;
        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void withdrawSavingsreceipt_Load(object sender, EventArgs e)
        {
            lblAccNum.Text = AccountInfo.accountNumber;
            lblAmountDeduc.Text = withdrawalamount.ToString();
            lblCurrentBal.Text = AccountInfo.savingsAmount.ToString();
        }
    }
}

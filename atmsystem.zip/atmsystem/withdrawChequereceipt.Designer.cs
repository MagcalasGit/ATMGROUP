﻿namespace atmsystem
{
    partial class withdrawChequereceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(withdrawChequereceipt));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            lblAccNum = new Label();
            lblAmountDeduc = new Label();
            lblCurrentBal = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(356, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(466, 12);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(230, 34);
            guna2HtmlLabel1.TabIndex = 8;
            guna2HtmlLabel1.Text = "Transaction Receipt";
            guna2HtmlLabel1.Click += guna2HtmlLabel1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(378, 75);
            label2.Name = "label2";
            label2.Size = new Size(191, 28);
            label2.TabIndex = 10;
            label2.Text = "Account Number:";

            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(389, 203);
            label1.Name = "label1";
            label1.Size = new Size(180, 28);
            label1.TabIndex = 12;
            label1.Text = "Current Balance:";

            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(365, 139);
            label3.Name = "label3";
            label3.Size = new Size(204, 28);
            label3.TabIndex = 13;
            label3.Text = "Amount Deducted:";

            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(575, 75);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(39, 28);
            lblAccNum.TabIndex = 14;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // lblAmountDeduc
            // 
            lblAmountDeduc.AutoSize = true;
            lblAmountDeduc.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountDeduc.ForeColor = Color.DarkSlateGray;
            lblAmountDeduc.Location = new Point(575, 139);
            lblAmountDeduc.Name = "lblAmountDeduc";
            lblAmountDeduc.Size = new Size(39, 28);
            lblAmountDeduc.TabIndex = 15;
            lblAmountDeduc.Text = "---";
            lblAmountDeduc.Click += lblAmountDeduc_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.AutoSize = true;
            lblCurrentBal.Font = new Font("Segoe UI Emoji", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(575, 203);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(39, 28);
            lblCurrentBal.TabIndex = 16;
            lblCurrentBal.Text = "---";
            lblCurrentBal.Click += lblCurrentBal_Click;
            // 
            // proceedBtn
            // 
            proceedBtn.BorderColor = Color.DarkCyan;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges7;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.DarkSlateGray;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(378, 272);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            proceedBtn.Size = new Size(282, 45);
            proceedBtn.TabIndex = 17;
            proceedBtn.Text = "Proceed to Merchant";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // withdrawChequereceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(800, 329);
            Controls.Add(proceedBtn);
            Controls.Add(lblCurrentBal);
            Controls.Add(lblAmountDeduc);
            Controls.Add(lblAccNum);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "withdrawChequereceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "withdrawChequereceipt";
            Load += withdrawChequereceipt_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label lblAccNum;
        private Label lblAmountDeduc;
        private Label lblCurrentBal;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
    }
}
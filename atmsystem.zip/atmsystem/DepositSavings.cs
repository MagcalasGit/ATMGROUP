﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class DepositSavings : Form
    {
        public DepositSavings()
        {
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void txtDepositSavings_TextChanged(object sender, EventArgs e)
        {
            double amount;
            if (!double.TryParse(txtDepositSavings.Text, out amount))
            {
                txtDepositSavings.Text = "";
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double depositAmount;
            if (double.TryParse(txtDepositSavings.Text, out depositAmount))
            {
                AccountInfo.savingsAmount += depositAmount;
                txtDepositSavings.Text = "";
                depositSavingsrecepit receiptForm = new depositSavingsrecepit(depositAmount);
                this.Hide();
                receiptForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }
    }
}

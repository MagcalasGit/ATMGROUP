﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class depositSavingsrecepit : Form
    {
        private double depositAmount;
        public depositSavingsrecepit(double depositAmount)
        {
            InitializeComponent();
            this.depositAmount = depositAmount;
        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void depositSavingsrecepit_Load(object sender, EventArgs e)
        {
            lblAccNum.Text = AccountInfo.accountNumber;
            lblAmountAdded.Text = depositAmount.ToString();
            lblCurrentBalAdd.Text = AccountInfo.savingsAmount.ToString();
        }

        private void lblAmountAdded_Click(object sender, EventArgs e)
        {

        }

        private void lblCurrentBalAdd_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

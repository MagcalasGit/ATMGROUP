﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class DepositCheque : Form
    {
        public DepositCheque()
        {
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void txtDepositCheq_TextChanged(object sender, EventArgs e)
        {
            double amount;
            if (!double.TryParse(txtDepositCheq.Text, out amount))
            {
                txtDepositCheq.Text = "";
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double depositAmount;
            if (double.TryParse(txtDepositCheq.Text, out depositAmount))
            {
                AccountInfo.chequeAmount += depositAmount;
                txtDepositCheq.Text = "";
                depositChequereceipt receiptForm = new depositChequereceipt(depositAmount);
                this.Hide();
                receiptForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private void DepositCheque_Load(object sender, EventArgs e)
        {

        }
    }
}

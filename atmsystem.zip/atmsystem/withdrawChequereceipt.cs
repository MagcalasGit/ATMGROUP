﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class withdrawChequereceipt : Form
    {
        private double withdrawalamount;
        public withdrawChequereceipt(double withdrawalamount)
        {
            InitializeComponent();
            this.withdrawalamount = withdrawalamount;
        }

        private void withdrawChequereceipt_Load(object sender, EventArgs e)
        {
            lblAccNum.Text = AccountInfo.accountNumber;
            lblAmountDeduc.Text = withdrawalamount.ToString();
            lblCurrentBal.Text = AccountInfo.chequeAmount.ToString();
        }

        private void lblAccNum_Click(object sender, EventArgs e)
        {

        }

        private void lblAmountDeduc_Click(object sender, EventArgs e)
        {

        }

        private void lblCurrentBal_Click(object sender, EventArgs e)
        {

        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}

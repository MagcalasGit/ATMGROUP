﻿namespace atmsystem
{
    partial class DepositForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepositForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            DepositChequeBtn = new Guna.UI2.WinForms.Guna2Button();
            DepositSavingsBtn = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(450, 425);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(167, 447);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(102, 34);
            guna2HtmlLabel1.TabIndex = 10;
            guna2HtmlLabel1.Text = "DEPOSIT";
            // 
            // cancelBtn
            // 
            cancelBtn.BorderColor = Color.DarkCyan;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges1;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.DarkSlateGray;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(102, 643);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 15;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // DepositChequeBtn
            // 
            DepositChequeBtn.BorderColor = Color.DarkCyan;
            DepositChequeBtn.BorderRadius = 15;
            DepositChequeBtn.BorderThickness = 2;
            DepositChequeBtn.CustomizableEdges = customizableEdges3;
            DepositChequeBtn.DisabledState.BorderColor = Color.DarkGray;
            DepositChequeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            DepositChequeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            DepositChequeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            DepositChequeBtn.FillColor = Color.DarkSlateGray;
            DepositChequeBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositChequeBtn.ForeColor = Color.White;
            DepositChequeBtn.Location = new Point(102, 580);
            DepositChequeBtn.Name = "DepositChequeBtn";
            DepositChequeBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            DepositChequeBtn.Size = new Size(235, 48);
            DepositChequeBtn.TabIndex = 14;
            DepositChequeBtn.Text = "Cheque";
            DepositChequeBtn.Click += DepositChequeBtn_Click;
            // 
            // DepositSavingsBtn
            // 
            DepositSavingsBtn.BorderColor = Color.DarkCyan;
            DepositSavingsBtn.BorderRadius = 15;
            DepositSavingsBtn.BorderThickness = 2;
            DepositSavingsBtn.CustomizableEdges = customizableEdges5;
            DepositSavingsBtn.DisabledState.BorderColor = Color.DarkGray;
            DepositSavingsBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            DepositSavingsBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            DepositSavingsBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            DepositSavingsBtn.FillColor = Color.DarkSlateGray;
            DepositSavingsBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositSavingsBtn.ForeColor = Color.White;
            DepositSavingsBtn.Location = new Point(102, 517);
            DepositSavingsBtn.Name = "DepositSavingsBtn";
            DepositSavingsBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            DepositSavingsBtn.Size = new Size(235, 48);
            DepositSavingsBtn.TabIndex = 13;
            DepositSavingsBtn.Text = "Savings";
            DepositSavingsBtn.Click += DepositSavingsBtn_Click;
            // 
            // DepositForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(452, 710);
            Controls.Add(cancelBtn);
            Controls.Add(DepositChequeBtn);
            Controls.Add(DepositSavingsBtn);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DepositForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DepositForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
        private Guna.UI2.WinForms.Guna2Button DepositChequeBtn;
        private Guna.UI2.WinForms.Guna2Button DepositSavingsBtn;
    }
}